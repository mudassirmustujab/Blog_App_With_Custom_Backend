const db = require("../models");



let blog_data = []


for (let index = 0; index < 5000; index++) {

    let author_id = "54014617-377f-4c58-8e62-999269bd8127"
    let title = `blog_title_dummy_${index+1}`
    let description = `blog_description_dummy_${index+1}`
    let thumbnail = `blog_thumbnail_dummy_`
    blog_data.push({author_id,title,description,thumbnail})
    
};



const blog_dummy=async()=>{

    await db.blogs.bulkCreate(blog_data)

    console.log("data uploaded");

}

module.exports = blog_dummy


