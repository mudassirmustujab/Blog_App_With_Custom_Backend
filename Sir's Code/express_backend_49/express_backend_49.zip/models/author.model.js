const { DataTypes } = require("sequelize");
const sequelize = require("../config/db.config");

const AUTHOR=sequelize.define("Author", {
  id: {
    primaryKey: true,
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4, // Or DataTypes.UUIDV1
    unique: true,
  },
  qualification: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  publications_count: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  user_id:{
    type: DataTypes.UUID,
    unique:true
  }

});

module.exports = AUTHOR
