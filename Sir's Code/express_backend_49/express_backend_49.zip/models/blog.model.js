const { DataTypes } = require("sequelize");
const sequelize = require("../config/db.config");

const BLOG=sequelize.define("Blog", {
  id: {
    primaryKey: true,
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4, // Or DataTypes.UUIDV1
    unique: true,
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false,
},
description: {
    type: DataTypes.TEXT,
    allowNull: false,
},
thumbnail:{
    
    type: DataTypes.STRING,
    allowNull: false,

},
images:{
    
    type: DataTypes.STRING,
    allowNull: true,
  },
  author_id:{
        type: DataTypes.UUID,
        allowNull:false

  }

});

module.exports = BLOG
