const USER =require('../models/user.model')
const AUTHOR =require('../models/author.model')
const BLOG =require('../models/blog.model')
const CATEGORY = require('../models/category.model')



const db = {}

db.users = USER
db.authors = AUTHOR
db.blogs = BLOG
db.categories = CATEGORY


db.users.hasOne(db.authors,{foreignKey:"user_id",onDelete: 'cascade'})
db.authors.belongsTo(db.users,{foreignKey:"user_id",onDelete: 'cascade'})

db.authors.hasMany(db.blogs,{foreignKey:"author_id",onDelete: 'cascade'})
db.blogs.belongsTo(db.authors,{foreignKey:"author_id",onDelete: 'cascade'})




module.exports = db 

