const express = require("express");
const { users_get, user_get, user_post, user_patch, user_delete } = require("../controllers/user.controller");

const user_routes = express.Router(); 

user_routes.get("/", users_get);
user_routes.get("/:id", user_get);
user_routes.post("/", user_post);
user_routes.patch("/:id", user_patch);
user_routes.delete("/:id", user_delete);

module.exports = user_routes;
