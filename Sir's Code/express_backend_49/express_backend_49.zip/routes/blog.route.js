const express = require("express");
const {getBlogs,getBlog,postBlog,patchBlog,deleteBlog} = require('../controllers/blog.controller')
const blog_router = express.Router()

blog_router.get('/',getBlogs)
blog_router.get('/:id',getBlog)
blog_router.post('/',postBlog)
blog_router.patch('/:id',patchBlog)
blog_router.delete('/:id',deleteBlog)

module.exports = blog_router