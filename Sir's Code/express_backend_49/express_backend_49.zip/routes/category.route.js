const express = require("express");
const {getAuthors,getAuthor,postAuthor,patchAuthor,deleteAuthor} = require('../controllers/author.controller')
const category_router = express.Router()

category_router.get('/',getAuthors)
category_router.get('/:id',getAuthor)
category_router.post('/',postAuthor)
category_router.patch('/:id',patchAuthor)
category_router.delete('/:id',deleteAuthor)

module.exports = category_router
