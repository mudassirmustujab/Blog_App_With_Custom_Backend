const express = require('express')

const author_routes = express.Router()

author_routes.get('/',function(req,res){

    res.status(200).json({msg:"authors get resource accesses"})
})
author_routes.get('/:id',function(req,res){

    res.status(200).json({msg:"author get single resource accesses"})
})
author_routes.post('/',function(req,res){

    res.status(200).json({msg:"author post resource accesses"})
})
author_routes.patch('/:id',function(req,res){

    res.status(200).json({msg:"author update resource accesses"})
})
author_routes.delete('/:id',function(req,res){

    res.status(200).json({msg:"author delete resource accesses"})
})

module.exports = author_routes