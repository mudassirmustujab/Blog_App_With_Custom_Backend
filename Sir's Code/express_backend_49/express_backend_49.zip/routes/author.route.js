const express = require("express");
const {getAuthors,getAuthor,postAuthor,patchAuthor,deleteAuthor} = require('../controllers/author.controller')
const author_router = express.Router()

author_router.get('/',getAuthors)
author_router.get('/:id',getAuthor)
author_router.post('/',postAuthor)
author_router.patch('/:id',patchAuthor)
author_router.delete('/:id',deleteAuthor)

module.exports = author_router