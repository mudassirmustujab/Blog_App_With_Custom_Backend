const app = require("./app");
let port = 8000

// starting server 
app.listen(port ,function(error){

    error 
    ? 
    console.log(`error while starting server ${error}`)
    :
    console.log(`server strted successfully at ${port}`)
    
})