const fs = require('fs')
const path = require('path')


const root_dir =path.resolve(__dirname,'../')   


module.exports ={root_dir}