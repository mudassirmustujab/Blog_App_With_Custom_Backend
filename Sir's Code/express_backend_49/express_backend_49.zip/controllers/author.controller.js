const db = require("../models")

const getAuthors =  async(req,res)=>{
    try {
        res.status(200).json({msg:"success"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const getAuthor =  async(req,res)=>{
    try {
        res.status(200).json({msg:"success"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const postAuthor =  async(req,res)=>{
    try {

        const {qualification,user_id,publications_count} = req.body 

        const author = await db.authors.create({publications_count,qualification,user_id} )

        res.status(200).json({msg:"success created successfully"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const patchAuthor =  async(req,res)=>{
    try {
        res.status(200).json({msg:"success"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const deleteAuthor =  async(req,res)=>{
    try {
        res.status(200).json({msg:"success"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
}


module.exports = {getAuthors,getAuthor,postAuthor,patchAuthor,deleteAuthor}