const fs = require('fs')
const path = require('path');
const { root_dir } = require('../utils/root_dir.util');


// let user_file_path = root_dir + "/" + "db" + "/" + "users.txt"  
let user_file_path = path.join(root_dir,"db","users.txt")

const users_get = function (req, res) {
  try {
    res.status(200).json({ msg: "get single user resource accessed" });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};
const user_get = function (req, res) {
  try {
    res.status(200).json({ msg: "get users resource accessed" });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};
const user_post = function (req, res) {
  try {
    console.log("inside post controller ...");
    console.log(req.body);

    fs.appendFileSync(user_file_path, JSON.stringify(req.body))

    res.status(200).json({ msg: "post user resource accessed" });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};
const user_patch = function (req, res) {
  try {
    res.status(200).json({ msg: "update user resource accessed" });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};
const user_delete = function (req, res) {
  try {
    res.status(200).json({ msg: "delete user resource accessed" });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
};

module.exports = { users_get, user_get, user_post, user_patch, user_delete };
