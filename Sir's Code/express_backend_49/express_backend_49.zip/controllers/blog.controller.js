const db = require('../models')

const getBlogs =  async(req,res)=>{
    try {
        console.log("query string ..",req.query);
        if(req.query){


        }

        const blogs =await db.blogs.findAll({limit: 100, })

        res.status(200).json({msg:"success",data:blogs})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const getBlog =  async(req,res)=>{
    try {

        const {id}= req.params

        const blog =await db.blogs.findOne({where:{id}})
        
        res.status(200).json({msg:"success",data:blog})
        
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const postBlog =  async(req,res)=>{
    try {

        const {title,description,author_id,thumbnail} = req.body

        const blog= await db.blogs.create({title,description,author_id,thumbnail})
        
        res.status(200).json({msg:"posted successfully"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const patchBlog =  async(req,res)=>{
    try {
        const {title,description,author_id} = req.body
        const {id} = req.params

        const blog = await db.blogs.update({title,description,author_id},{where:{id}})

        res.status(200).json({msg:"updated successfully"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const deleteBlog =  async(req,res)=>{
    try {

        const {id} = req.params

        const blog = await db.blogs.destroy({where:{id}})
        res.status(200).json({msg:"deleted successfully"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
}


module.exports = {getBlogs,getBlog,postBlog,patchBlog,deleteBlog}