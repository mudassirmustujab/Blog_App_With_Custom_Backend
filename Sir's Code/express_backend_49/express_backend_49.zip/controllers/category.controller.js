const getCategorys =  async(req,res)=>{
    try {
        res.status(200).json({msg:"success"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const getCategory =  async(req,res)=>{
    try {
        res.status(200).json({msg:"success"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const postCategory =  async(req,res)=>{
    try {
        res.status(200).json({msg:"success"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const patchCategory =  async(req,res)=>{
    try {
        res.status(200).json({msg:"success"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
} 
const deleteCategory =  async(req,res)=>{
    try {
        res.status(200).json({msg:"success"})
        
    } catch (error) {
        res.status(500).json({msg:error.message})
    }
}


module.exports = {getCategorys,getCategory,postCategory,patchCategory,deleteCategory}