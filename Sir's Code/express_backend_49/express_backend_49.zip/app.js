const express = require('express')
const user_routes = require("./routes/user.route");
const author_routes = require('./routes/author.route');

const app = express()

app.use(express.json())

// user resource
app.use('/api/v1/user',user_routes)
// author resource
app.use('/api/v1/author',author_routes)
// blog resource v1
// app.use('/api/v1/blog')
// blog resource v2
// app.use('/api/v2/blog')








module.exports = app

